# Structure / 20

An architectural art presentation made from structure1.zip, with glass and concrete as the primary material language.

## View in a browser

1. Open `index.html` in Chrome, Safari, Firefox, or Edge. Keep the folder contents together. No server or internet is required.
2. Select Spatial model, Floor plans, Elevations, Section, or Original sculpture.
3. Drag to rotate; scroll to zoom. Select floors 1–20, adjust glass opacity, or cut away the floors above your selection.
4. Open `drawing-set.html` for all 23 sheets. Use Print / Save as PDF with landscape orientation. SVG files also open directly in a browser.

For local HTTP viewing, run `python3 -m http.server 8000 --bind 127.0.0.1` from this folder, then open http://localhost:8000. The static folder can also be placed on a web host; it has no build step or external dependencies.

## Design choices

- Twenty levels, from +0.00 m to +68.40 m, plus a roof at +72.00 m.
- Imagined floor spacing of 3.60 m; 0.28 m floor plate thickness is a visual assumption.
- Four sculptural bays with major concrete bands at 0, 21.6, 39.6, 54, and 72 m.
- Glass enclosure, curved concrete ribs, and conceptual central core.
- Approximate maximum envelope: 35 × 30.45 m. Waisted intermediate floors.
- Open art floors: no residential or commercial program is imposed.
- Plan north is a drawing convention, not a real site orientation.

## Source and interpretation

The supplied archive contains glTF mesh geometry and an Open Brush/Tilt Brush source file; the glTF generator identifies Open Brush 2.31.0. Both mesh objects were read, totaling 106,428 vertices / 35,476 triangles. Mesh nodes have no transforms. The Original sculpture view preserves those vertices and triangles, uniformly normalizes total height to 76 imagined metres, and omits original brush materials/textures. Raw files are preserved under source/model.

The proposed building is a new geometric interpretation inspired by the source's four main bays, tier bands, and inward sweeping strokes. It is not a measured reconstruction. The source height includes projecting strokes, while the proposed roof datum is 72 m. The source did not establish real-world dimensions or 20 discrete architectural floor plates; these were added in response to the user's description.

The floor plans, elevations, section, and model use the same proposed floor datums and envelope formula. Plan symbols, ribs and core are illustrative, and no engineering or code-compliance analysis is implied. This is a completed art presentation, not construction documentation.

## Files

- index.html / app.js / design.js / mesh.js: offline interactive viewer.
- drawing-set.html: printable 23-sheet collection.
- drawings/: 20 vector floor plans, 2 elevations, 1 section.
- floor-schedule.csv: all level datums and envelope dimensions.
- build.py: regenerates drawing and design data with standard Python.
- source/: original extracted source assets.
