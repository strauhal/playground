# Structure / 200 — The Common Void

An architectural art project with glass and concrete terraces around a shared open atrium.

## View
Open index.html in a browser with the folder intact. No internet or server is required. Drag to orbit; scroll to zoom. Select floors 1–200. Open front removes the front half to reveal the atrium; Terrace detail isolates up to nine nearby floors. Use both to inspect the shared terraces. Disable Open front for the complete annular building. The original sculpture remains available unchanged.

Open drawing-set.html for all 203 vector sheets, then print or save as PDF. Each SVG can also be opened separately. For HTTP viewing, run python3 -m http.server 8000 --bind 127.0.0.1 from this folder.

## Current design
- Exact circular outer diameter: 402.336 m (quarter mile) in every horizontal direction.
- 200 floors: level 1 at 0 m; level 200 at 1194 m; annular roof edge at 1200 m.
- Floor spacing: 6 m. Illustrative slab thickness: 0.28 m.
- Continuous open-to-sky atrium: 230–280 m diameter, with no central core or floor plates crossing it.
- Four repeated terrace bowls, each 50 floors tall; inner edges step outward every five floors.
- Shared terraces run from the atrium edge to radius 165 m, giving 25–50 m terrace depth.
- Enclosed perimeter rooms occupy radius 165–201.168 m; four illustrative 12 x 18 m circulation cores stand at radius 183 m.
- Transparent 1.2 m balustrades at the inner edge; glass fronts behind the terraces.
- Curved ribs remain within the perimeter band, outside the shared void.
- All floors, plans and the section use the same inner-radius schedule.

The spatial intent is mutual visibility across the atrium and between nearby levels. Slabs, distance and perspective prevent literal visibility of every person on every level. This is an artistic composition, not an engineered or code-reviewed building.

## Source
Raw uploaded files remain under source/. The original glTF contains 106,428 vertices and 35,476 triangles. Its geometry is shown in neutral material, normalized to 76 imaginary metres. The proposed tower is a new interpretation, not a measured reconstruction. Earlier 20- and 60-floor packages are separate historical revisions.

## Contents
index.html, app.js, design.js, mesh.js: offline viewer.
drawing-set.html: 203-sheet printable collection.
drawings/: 200 floor plans, two elevations, one atrium section.
floor-schedule.csv: level, diameter, atrium and terrace dimensions.
build.py: drawing/data generator using standard Python.
