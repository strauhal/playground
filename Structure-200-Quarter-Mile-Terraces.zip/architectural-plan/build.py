import json,math
from pathlib import Path
P=Path(__file__).parent
H=1200; floors=200; SPACING=6.; DIAMETER=402.336; R=DIAMETER/2
bands=[0,300,600,900,1200]
def inner(y):
 # Four stepped bowls: five-level terrace groups follow each sculptural bay.
 f=min(199,int(y/SPACING));step=(f%50)//5
 return 115+25*step/9
levels=[dict(level=i+1,z=i*SPACING,width=DIAMETER,depth=DIAMETER,atriumDiameter=round(inner(i*SPACING)*2,3),terraceDepth=round(165-inner(i*SPACING),3)) for i in range(floors)]
data=dict(diameter=DIAMETER,height=H,spacing=SPACING,segments=192,bands=bands,levels=levels,outerRoomRadius=165,coreRadius=183)
(P/'design.js').write_text('const DESIGN='+json.dumps(data,separators=(',',':'))+';')
D=P/'drawings';D.mkdir(exist_ok=True)
def head(title,subtitle,code,tall=False):
 h=1700 if tall else 850;foot=h-95
 return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 {h}"><defs><pattern id="hatch" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><path d="M0 0V6" stroke="#718088" stroke-width="1"/></pattern></defs><style>text{{font-family:Arial,sans-serif;fill:#243e49}}.small{{font-size:12px;letter-spacing:1px}}.line{{fill:none;stroke:#254451;stroke-width:1.2}}.fine{{fill:none;stroke:#82969b;stroke-width:.6}}.dash{{fill:none;stroke:#82969b;stroke-width:.7;stroke-dasharray:7 6}}</style><rect width="1200" height="{h}" fill="#f6f4ee"/><rect x="25" y="25" width="1150" height="{h-50}" class="fine"/><text x="55" y="67" font-size="27">STRUCTURE / 200</text><text x="55" y="92" class="small">{title} · {subtitle}</text><path d="M55 115H1145 M55 {foot}H1145" class="fine"/><text x="55" y="{foot+30}" class="small">THE COMMON VOID / GLASS + CONCRETE / QUARTER-MILE DIAMETER</text><text x="55" y="{foot+52}" font-size="10">ART STUDY / Imagined dimensions in metres. Architectural expression, not construction documentation.</text><text x="1030" y="{foot+35}" font-size="22">{code}</text>'''
def plan(i):
 y=i*SPACING;ir=inner(y);s=1.22;cx=425;cy=422
 a=[head(f'LEVEL {i+1:03d} / TERRACE PLAN',f'+{y:.2f} m',f'P-{i+1:03d}')]
 a.append(f'<circle cx="{cx}" cy="{cy}" r="{R*s}" fill="#dce8e8" stroke="#163843" stroke-width="2"/><circle cx="{cx}" cy="{cy}" r="{165*s}" fill="#e8dfce" stroke="#5b7b86"/><circle cx="{cx}" cy="{cy}" r="{ir*s}" fill="#f6f4ee" stroke="#244b58" stroke-width="2"/><circle cx="{cx}" cy="{cy}" r="{(ir+1.2)*s}" class="fine"/>')
 for n in range(4):
  t=n*math.pi/2;xx=cx+183*s*math.cos(t);yy=cy+183*s*math.sin(t)
  a.append(f'<rect x="{xx-6*s}" y="{yy-9*s}" width="{12*s}" height="{18*s}" fill="url(#hatch)" stroke="#254451"/><text x="{xx}" y="{yy+3}" font-size="8" text-anchor="middle">C{n+1}</text>')
 for n in range(24):
  t=n*math.pi/12;rr=ir+5;xx=cx+rr*s*math.cos(t);yy=cy+rr*s*math.sin(t)
  a.append(f'<circle cx="{xx}" cy="{yy}" r="1.6" fill="#ad6848"/>')
 a.append(f'<text x="{cx}" y="{cy-15}" text-anchor="middle" class="small">OPEN ATRIUM</text><text x="{cx}" y="{cy+8}" text-anchor="middle" font-size="12">Ø {2*ir:.2f} m / OPEN TO SKY</text><path d="M{cx-ir*s+8} {cy+30}H{cx+ir*s-8}" stroke="#b87554" stroke-dasharray="6 5"/><text x="{cx}" y="{cy+52}" font-size="10" text-anchor="middle">SIGHTLINE ACROSS SHARED VOID</text>')
 a.append(f'<path d="M{cx-R*s} 700H{cx+R*s}m0 -5v10M{cx-R*s} 695v10" class="line"/><text x="{cx}" y="726" text-anchor="middle" class="small">402.336 m / QUARTER MILE</text>')
 notes=['01 / Glass outer enclosure','02 / Enclosed perimeter rooms','03 / Shared inward-facing terrace','04 / Transparent atrium balustrade','05 / Four perimeter circulation cores','06 / Open, unobstructed centre','',f'Terrace depth / {165-ir:.2f} m',f'Atrium diameter / {ir*2:.2f} m','Floor-to-floor / 6.00 m','Terraces step every five floors.','Four repeated sculptural bowls.','People symbols are illustrative.']
 for k,t in enumerate(notes):a.append(f'<text x="760" y="{220+28*k}" font-size="12">{t}</text>')
 a.append('<path d="M760 680h122m-122 -5v10m61 -10v10m61 -10v10" class="line"/><text x="760" y="703" font-size="11">0　　　　　 50　　　　 100 m</text></svg>')
 return ''.join(a)
for i in range(floors):(D/f'plan-{i+1:02d}.svg').write_text(plan(i))
def elevation(section=False,side=False):
 a=[head('ATRIUM SECTION A—A' if section else ('EAST ELEVATION' if side else 'SOUTH ELEVATION'),'200 FLOORS / ROOF +1200 m','A-301' if section else ('A-202' if side else 'A-201'),True)]
 s=1.06;cx=555;base=1510;r=R*s
 if not section:a.append(f'<rect x="{cx-r}" y="{base-H*s}" width="{r*2}" height="{H*s}" fill="#dfebeb" stroke="#254451"/>')
 for i in range(floors):
  y=i*SPACING;zz=base-y*s;ir=inner(y)*s
  if section:
   for sign in [-1,1]:
    xa=cx-r if sign<0 else cx+ir;xb=cx-ir if sign<0 else cx+r
    a.append(f'<path d="M{xa} {zz}H{xb}" stroke="#294854" stroke-width="1"/>')
    xrail=cx+sign*ir;a.append(f'<path d="M{xrail} {zz}v-2" stroke="#6c9ba9" stroke-width=".7"/>')
  else:a.append(f'<path d="M{cx-r} {zz}H{cx+r}" stroke="#294854" stroke-width=".6"/>')
  if i%10==0 or i==199:a.append(f'<text x="825" y="{zz+3}" font-size="10">L{i+1:03d} / +{y:.0f} m</text>')
 if section:
  for sign in [-1,1]:
   xx=cx+sign*183*s;a.append(f'<rect x="{xx-6*s}" y="{base-H*s}" width="{12*s}" height="{H*s}" fill="url(#hatch)" stroke="#294854" stroke-width=".6"/>')
  a.append(f'<text x="{cx}" y="810" text-anchor="middle" class="small">OPEN ATRIUM</text><text x="{cx}" y="834" text-anchor="middle" font-size="11">230–280 m clear diameter</text><path d="M{cx-110*s} 855H{cx+110*s}" stroke="#b87554" stroke-dasharray="6 5"/>')
 else:
  for aa,bb in zip(bands,bands[1:]):
   for sign in [-1,1]:
    points=[f'{cx+sign*(168+32*abs(2*k/80-1)**1.8)*s:.3f},{base-(aa+(bb-aa)*k/80)*s:.3f}' for k in range(81)]
    a.append('<path d="M'+' L'.join(points)+'" fill="none" stroke="#6b8079" stroke-width="2"/>')
 for y in bands:
  if section:
   for sign in [-1,1]:a.append(f'<path d="M{cx+sign*140*s} {base-y*s}H{cx+sign*r}" stroke="#294854" stroke-width="2"/>')
  else:a.append(f'<path d="M{cx-r} {base-y*s}H{cx+r}" stroke="#294854" stroke-width="2"/>')
 a.append(f'<path d="M270 {base}V{base-H*s}" class="line"/><text x="250" y="940" transform="rotate(-90 250 940)" class="small">1200 m / 200 FLOORS AT 6 m</text><path d="M{cx-r} 1550H{cx+r}" class="line"/><text x="{cx}" y="1574" text-anchor="middle" class="small">402.336 m / QUARTER-MILE DIAMETER</text><text x="55" y="164" font-size="12">Ring-shaped floors face a common open centre; circulation moves to the perimeter.</text><text x="55" y="187" font-size="12">Stepped terraces and transparent balustrades create views across and between nearby levels.</text></svg>')
 return ''.join(a)
for name,body in [('south-elevation.svg',elevation()),('east-elevation.svg',elevation(side=True)),('section.svg',elevation(True))]:(D/name).write_text(body)
(P/'floor-schedule.csv').write_text('Level,Proposed datum m,Width m,Depth m,Atrium diameter m,Terrace depth m\n'+'\n'.join(','.join(str(v[k]) for k in ['level','z','width','depth','atriumDiameter','terraceDepth']) for v in levels))
print('Generated 200 ring-floor plans, atrium section, two elevations, and schedule.')
