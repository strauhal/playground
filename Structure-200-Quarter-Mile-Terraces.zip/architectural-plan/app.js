'use strict';
const $=id=>document.getElementById(id),canvas=$('model'),ctx=canvas.getContext('2d');
let view='model',angle=.67,tilt=.28,zoom=1,level=10,drag=null,scheduled=false,modelDirty=true;
const triangles=[];
function face(points,color,alpha=1,line=null){triangles.push({points,color,alpha,line});}
function ring(y,r=DESIGN.diameter/2){return Array.from({length:192},(_,i)=>{const t=i*Math.PI/96;return [r*Math.cos(t),y,r*Math.sin(t)]});}
function box(x,y,z,w,h,d,color){const p=[[x,y,z],[x+w,y,z],[x+w,y,z+d],[x,y,z+d],[x,y+h,z],[x+w,y+h,z],[x+w,y+h,z+d],[x,y+h,z+d]];for(const ids of [[0,1,5,4],[1,2,6,5],[2,3,7,6],[3,0,4,7],[4,5,6,7]])face(ids.map(i=>p[i]),color);}
function build(){triangles.length=0;const detail=$('detail').checked;const low=detail?Math.max(0,level-5):0;const high=detail?Math.min(200,level+4):($('cut').checked?level:200);const opacity=+$('glass').value/100;
 if(!detail)box(-230,-1,-230,460,.5,460,'#d3d8d2');
 for(let l=low;l<high;l++){
  const d=DESIGN.levels[l],y=d.z,ir=d.atriumDiameter/2,outer=ring(y),inside=ring(y,ir),rooms=ring(y,165),back=ring(y+6),rail=ring(y+1.2,ir);const selected=l===level-1;
  for(let i=0;i<192;i++){const k=(i+1)%192;
   // Actual annular floor faces: no polygon ever spans the atrium.
   face([outer[i],outer[k],rooms[k],rooms[i]],selected?'#c99c7c':'#b9c3bc');
   face([rooms[i],rooms[k],inside[k],inside[i]],selected?'#d29a70':'#ded4bf');
   face([inside[i],inside[k],[inside[k][0],y-.28,inside[k][2]],[inside[i][0],y-.28,inside[i][2]]],'#547079',1,'#294854');
   face([outer[i],outer[k],[outer[k][0],y-.28,outer[k][2]],[outer[i][0],y-.28,outer[i][2]]],'#718b8c',1,'#294854');
   if(opacity>0)face([outer[i],outer[k],back[k],back[i]],'#acd4dd',opacity);
   face([inside[i],inside[k],rail[k],rail[i]],'#91bfca',.24);
  }
  // Four perimeter cores, entirely outside the clear atrium.
  for(let c=0;c<4;c++){const t=c*Math.PI/2,x=183*Math.cos(t),z=183*Math.sin(t);box(x-6,y,z-9,12,6,18,'#788980');}
  // Interior room front: glass behind the shared terrace.
  const front=ring(y+5.5,165);
  for(let i=0;i<192;i+=4){const k=(i+4)%192;face([rooms[i],rooms[k],front[k],front[i]],'#a4c7ce',.13);}
 }
 // Retain curved sculptural ribs in the perimeter band; leave the middle clear.
 for(let bay=0;bay<4;bay++){const a=DESIGN.bands[bay],b=DESIGN.bands[bay+1];for(let n=0;n<8;n++){const t=n*Math.PI/4;for(let k=0;k<50;k++){const y=a+(b-a)*k/50,yy=a+(b-a)*(k+1)/50;if(y<low*6||yy>high*6)continue;const r=168+32*Math.abs(2*k/50-1)**1.8,rr=168+32*Math.abs(2*(k+1)/50-1)**1.8;face([[r*Math.cos(t)-1,y,r*Math.sin(t)-1],[r*Math.cos(t)+1,y,r*Math.sin(t)+1],[rr*Math.cos(t)+1,yy,rr*Math.sin(t)+1],[rr*Math.cos(t)-1,yy,rr*Math.sin(t)-1]],'#627e73');}}}
 // The roof is also an annulus. The centre remains open to sky.
 if(high===200&&!detail){const ro=ring(1200),ri=ring(1200,140);for(let i=0;i<192;i++){const k=(i+1)%192;face([ro[i],ro[k],ri[k],ri[i]],'#9ea99f');}}
 if($('sectionModel').checked){let keep=0;for(const f of triangles){if(f.points.reduce((sum,p)=>sum+p[2],0)/f.points.length<=0)triangles[keep++]=f;}triangles.length=keep;}
}
function project(p,w,h){let [x,y,z]=p;let a=x*Math.cos(angle)+z*Math.sin(angle),b=-x*Math.sin(angle)+z*Math.cos(angle);let v=(y-(view==='source'?38:($('detail').checked?(level-1)*6:DESIGN.height/2)))*Math.cos(tilt)-b*Math.sin(tilt),depth=(y-(view==='source'?38:($('detail').checked?(level-1)*6:DESIGN.height/2)))*Math.sin(tilt)+b*Math.cos(tilt);const s=Math.min(w/(view==='source'?70:DESIGN.diameter*1.65),h/(view==='source'?91:($('detail').checked?70:DESIGN.height)+DESIGN.diameter*Math.abs(Math.sin(tilt))+90))*zoom;return [w/2+a*s,h*.51-v*s,depth];}
function render(){scheduled=false;const w=canvas.clientWidth,h=canvas.clientHeight,dpr=Math.min(Math.max(devicePixelRatio||1,2),3);canvas.width=w*dpr;canvas.height=h*dpr;ctx.scale(dpr,dpr);ctx.fillStyle='#e8eeeb';ctx.fillRect(0,0,w,h);
 ctx.strokeStyle='#d1dcd6';ctx.lineWidth=.6;for(let a=-50;a<=50;a+=5){for(const ends of [[[a,-1,-50],[a,-1,50]],[[-50,-1,a],[50,-1,a]]]){let p=ends.map(x=>project(x,w,h));ctx.beginPath();ctx.moveTo(...p[0].slice(0,2));ctx.lineTo(...p[1].slice(0,2));ctx.stroke();}}
 let faces;if(view==='source'){faces=[];for(let i=0;i<SOURCE_VERTICES.length;i+=3){faces.push({points:SOURCE_VERTICES.slice(i,i+3),color:'#526e73',alpha:.85});}}else{if(modelDirty){build();modelDirty=false;}faces=triangles;}
 const ff=faces.map(f=>({...f,p:f.points.map(p=>project(p,w,h))}));ff.forEach(f=>f.depth=f.p.reduce((s,p)=>s+p[2],0)/f.p.length);ff.sort((a,b)=>a.depth-b.depth);
 for(const f of ff){ctx.beginPath();ctx.moveTo(f.p[0][0],f.p[0][1]);for(let i=1;i<f.p.length;i++)ctx.lineTo(f.p[i][0],f.p[i][1]);ctx.closePath();ctx.globalAlpha=f.alpha;ctx.fillStyle=f.color;ctx.fill();if(f.line){ctx.globalAlpha=.95;ctx.lineWidth=.85;ctx.strokeStyle=f.line;ctx.stroke();}}ctx.globalAlpha=1;
}
function queue(){if(!scheduled){scheduled=true;requestAnimationFrame(render);}}
function update(){modelDirty=true;level=+$('level').value;const d=DESIGN.levels[level-1];$('levelValue').textContent=`${level} / 200`;$('datum').textContent=`+${d.z.toFixed(2)} m`;$('envelope').textContent=`${d.width.toFixed(3)} × ${d.depth.toFixed(3)} m`;const spatial=view==='model'||view==='source';canvas.style.display=spatial?'block':'none';$('drawing').style.display=spatial?'none':'block';$('stageLabel').hidden=!spatial;$('hint').hidden=!spatial;for(const id of ['glassField','cutField','interiorField'])$(id).hidden=view!=='model';$('levelField').hidden=view==='source'||view==='elevation'||view==='section';$('orbitButtons').hidden=!spatial;$('elevationField').hidden=view!=='elevation';$('saveDrawing').hidden=spatial;$('panelTitle').textContent=spatial?'MODEL CONTROLS':'DRAWING INFORMATION';$('stageLabel').textContent=view==='source'?'ORIGINAL MESH / NEUTRAL GEOMETRY VIEW':'AXONOMETRIC / PROPOSED INTERPRETATION';$('viewDescription').textContent=view==='source'?'Actual uploaded geometry, uniformly scaled for comparison. Brush textures are omitted.':view==='model'?'Quarter-mile circular floors surround a 230–280 m open atrium. Shared terraces face one another; four cores sit at the perimeter.':'Artistic drawing with imagined dimensions. Download the vector SVG for crisp printing at any size.';
 if(!spatial){const path=view==='plan'?`drawings/plan-${String(level).padStart(2,'0')}.svg`:view==='section'?'drawings/section.svg':`drawings/${$('elevation').value}-elevation.svg`;$('drawing').src=path;$('drawing').alt=view==='plan'?`Level ${level} architectural plan`:view+' architectural drawing';$('saveDrawing').href=path;}else queue();}
document.querySelectorAll('[data-view]').forEach(b=>b.onclick=()=>{view=b.dataset.view;document.querySelectorAll('[data-view]').forEach(x=>{x.classList.toggle('active',x===b);x.setAttribute('aria-pressed',x===b)});update();});
for(const id of ['level','glass','cut','elevation','sectionModel','detail'])$(id).addEventListener('input',update);
canvas.onpointerdown=e=>{drag=[e.clientX,e.clientY];canvas.setPointerCapture(e.pointerId)};canvas.onpointermove=e=>{if(!drag)return;angle+=(e.clientX-drag[0])*.008;tilt=Math.max(-.1,Math.min(1.1,tilt+(e.clientY-drag[1])*.005));drag=[e.clientX,e.clientY];queue()};canvas.onpointerup=canvas.onpointercancel=()=>drag=null;canvas.addEventListener('wheel',e=>{e.preventDefault();zoom=Math.max(.5,Math.min(2.5,zoom*Math.exp(-e.deltaY*.001)));queue()},{passive:false});$('rotateLeft').onclick=()=>{angle-=.3;queue()};$('rotateRight').onclick=()=>{angle+=.3;queue()};$('reset').onclick=()=>{angle=.67;tilt=.28;zoom=1;queue()};window.addEventListener('resize',queue);update();
