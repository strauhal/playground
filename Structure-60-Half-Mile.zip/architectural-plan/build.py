import json,math
from pathlib import Path
P=Path(__file__).parent
H=360; floors=60
SPACING=6.0
bands=[0,108,198,270,360]
DIAMETER=804.672
HORIZONTAL_SCALE=DIAMETER/35
def radius(y):
 return DIAMETER/2
def ring(y,n=192):
 r=radius(y)
 return [[r*math.cos(t),y,r*math.sin(t)] for t in [2*math.pi*i/n for i in range(n)]]
levels=[{'level':i+1,'z':round(i*SPACING,1),'width':round(radius(i*SPACING)*2,3),'depth':round(radius(i*SPACING)*2,3)} for i in range(floors)]
data={'diameter':DIAMETER,'height':H,'spacing':SPACING,'segments':192,'bands':bands,'levels':levels,'rings':[ring(i*H/80) for i in range(81)]}
(P/'design.js').write_text('const DESIGN='+json.dumps(data,separators=(',',':'))+';')
D=P/'drawings'; D.mkdir(exist_ok=True)
def head(title,subtitle,code):
 return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 850"><defs><pattern id="hatch" width="7" height="7" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><path d="M0 0V7" stroke="#718088" stroke-width="1"/></pattern></defs><style>text{{font-family:Arial,sans-serif;fill:#243e49}}.small{{font-size:12px;letter-spacing:1px}}.line{{fill:none;stroke:#254451;stroke-width:1.2}}.fine{{fill:none;stroke:#82969b;stroke-width:.6}}.dash{{fill:none;stroke:#82969b;stroke-width:.7;stroke-dasharray:7 6}}</style><rect width="1200" height="850" fill="#f6f4ee"/><rect x="25" y="25" width="1150" height="800" class="fine"/><text x="55" y="67" font-size="27">STRUCTURE / 60</text><text x="55" y="92" class="small">{title.upper()} · {subtitle}</text><path d="M55 115H1145 M55 755H1145" class="fine"/><text x="55" y="785" class="small">SCULPTURE TRANSLATED INTO ARCHITECTURE · GLASS + CONCRETE</text><text x="55" y="807" font-size="10">ART STUDY / Imagined dimensions in metres. Not a construction or engineering document. Scale bar governs digital viewing.</text><text x="1030" y="790" font-size="22">{code}</text>'''
def plan(i):
 y=i*SPACING;r=radius(y);s=13/HORIZONTAL_SCALE;cx=520;cy=423
 xy=[(cx+x*s,cy+z*s) for x,_,z in ring(y)]
 a=[head(f'Level {i+1:02d} / plan',f'DATUM +{y:.2f} m',f'A-{101+i}')]
 for x in [-300,-150,0,150,300]:
  a.append(f'<path d="M{cx+x*s} 160V690 M245 {cy+x*s}H795" class="dash"/>')
 a.append(f'<circle cx="{cx}" cy="{cy}" r="{r*s}" fill="#e3eeee" stroke="#163843" stroke-width="2"/>')
 xy2=[(cx+(x-cx)*.975,cy+(z-cy)*.975) for x,z in xy]
 a.append(f'<circle cx="{cx}" cy="{cy}" r="{r*s*.975}" fill="none" stroke="#426d7c" stroke-width="1"/>')
 # Core remains 8 x 12 metres at the new drawing scale.
 a.append(f'<g transform="translate({cx} {cy}) scale({1/HORIZONTAL_SCALE}) translate({-cx} {-cy})">')
 # core, conceptual stair and lift symbols
 a.append(f'<rect x="{cx-52}" y="{cy-78}" width="104" height="156" fill="url(#hatch)" stroke="#254451" stroke-width="3"/><rect x="{cx-43}" y="{cy-69}" width="86" height="138" fill="#f6f4ee" stroke="#254451"/>')
 for off in [-62,25]:
  a.append(f'<rect x="{cx-35}" y="{cy+off}" width="38" height="38" class="line"/>')
  for k in range(1,8):a.append(f'<path d="M{cx-35} {cy+off+k*4.6}h38" class="fine"/>')
 for xx in [cx+10]:
  a.append(f'<rect x="{xx}" y="{cy-19}" width="25" height="38" class="line"/><path d="M{xx} {cy-19}l25 38m0 -38l-25 38" class="fine"/>')
 a.append(f'<text x="{cx-34}" y="{cy+6}" font-size="9">CORE</text>')
 a.append('</g>')
 for t in range(8):
  th=t*math.pi/4;x=cx+(r-1)*math.cos(th)*s;z=cy+(r-1)*math.sin(th)*s
  a.append(f'<circle cx="{x}" cy="{z}" r="5" fill="#556671"/>')
 a.append(f'<path d="M{cx-r*s} 705H{cx+r*s} M{cx-r*s} 696v18 M{cx+r*s} 696v18" class="line"/><text x="{cx}" y="730" text-anchor="middle" class="small">{2*r:.3f} m / PROPOSED ENVELOPE</text>')
 a.append('<path d="M850 210v-50l-5 10m5 -10l5 10" class="line"/><text x="846" y="147" class="small">N*</text><text x="860" y="226" font-size="10">*Drawing orientation only</text>')
 notes=['01 / Glass perimeter','02 / Concrete floor plate','03 / Imagined 8 × 12 m core','04 / Sculptural concrete ribs','05 / Open exhibition floor','', 'Floor-to-floor / 6.00 m','Slab / 0.28 m visual assumption','Core symbols are illustrative.','No circulation compliance implied.']
 for k,txt in enumerate(notes):a.append(f'<text x="855" y="{310+k*26}" font-size="12">{txt}</text>')
 a.append('<path d="M855 660h112.99m-112.99 -5v10m56.495 -10v10m56.495 -10v10" class="line"/><text x="855" y="685" class="small">0　　　 100　　　200 m</text></svg>')
 return ''.join(a)
for i in range(floors):(D/f'plan-{i+1:02d}.svg').write_text(plan(i))
def elevation(section=False,side=False):
 a=[head('Longitudinal section' if section else ('East elevation' if side else 'South elevation'),'60 LEVELS / ROOF +360.00 m / DIAMETER 804.672 m','A-301' if section else ('A-202' if side else 'A-201'))]
 s=.99;cx=535;base=665;r=DIAMETER*s/2
 a.append(f'<rect x="{cx-r}" y="{base-H*s}" width="{2*r}" height="{H*s}" fill="#dce9e9" stroke="#254451" stroke-width="1.5"/>')
 for j in range(floors+1):
  y=j*SPACING;zz=base-y*s
  a.append(f'<path d="M{cx-r} {zz}H{cx+r}" stroke="#294854" stroke-width=".7"/>')
  if j%5==0 or j==59:
   a.append(f'<path d="M{cx+r+5} {zz}H965" class="fine"/><text x="972" y="{zz+3}" font-size="10">'+(f'L{j+1:02d}' if j<floors else 'ROOF')+f' / +{y:.2f}</text>')
 if section:
  a.append(f'<rect x="{cx-4*s}" y="{base-H*s}" width="{8*s}" height="{H*s}" fill="url(#hatch)" stroke="#254451"/>')
 else:
  for aa,bb in zip(bands,bands[1:]):
   for sign in [-1,1]:
    points=[]
    for k in range(81):
     y=aa+(bb-aa)*k/80;x=sign*(3+14.5*abs(2*k/80-1)**1.8)*HORIZONTAL_SCALE
     points.append(f'{cx+x*s:.3f},{base-y*s:.3f}')
    a.append('<path d="M'+' L'.join(points)+'" fill="none" stroke="#697778" stroke-width="2"/>')
 for y in bands:a.append(f'<path d="M{cx-r} {base-y*s}H{cx+r}" stroke="#294854" stroke-width="2"/>')
 a.append(f'<path d="M105 {base}V{base-H*s}m-6 0h12M99 {base}h12" class="line"/><text x="90" y="540" transform="rotate(-90 90 540)" class="small">360.00 m</text><path d="M{cx-r} 702H{cx+r}m0 -5v10M{cx-r} 697v10" class="line"/><text x="{cx}" y="725" text-anchor="middle" class="small">804.672 m / HALF-MILE DIAMETER</text><text x="55" y="165" class="small">'+('CUT A—A' if section else 'ORTHOGRAPHIC')+'</text><text x="55" y="192" font-size="12">60 circular platforms / 6 m floor spacing / every platform is half a mile across.</text></svg>')
 return ''.join(a)
(D/'south-elevation.svg').write_text(elevation());(D/'east-elevation.svg').write_text(elevation(side=True));(D/'section.svg').write_text(elevation(True))
(P/'floor-schedule.csv').write_text('Level,Proposed datum m,Width m,Depth m,Use\n'+'\n'.join(f"{v['level']},{v['z']},{v['width']},{v['depth']},Open art floor" for v in levels))
print('Generated 60 plans, two elevations, section, and model data.')
