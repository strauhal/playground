# Structure / 100 — Four Hourglass Bays

Open index.html in a browser. Refresh an already-open tab. Drag to orbit; scroll to zoom. Open front reveals the atrium; Terrace detail isolates nearby floors. drawing-set.html contains all 103 current sheets, printable to PDF.

100 stories, 6 m apart: top occupied datum 594 m, roof 600 m. Four 25-story hourglass bays reproduce the strong inward sweeps of the user's red-marked elevation. The narrowest point is 38% of the way up each bay, matching the low asymmetric pinch in the sketch. Circular profiles vary continuously from 200 m maximum diameter to 50 m at the waist.

Two blocks is an artistic assumption of two 100 m blocks: 200 m total width and depth at the broad platforms. It is not a site-specific city-block measurement. Floors remain perfect circles in plan.

The open atrium follows 55% of the outer radius (27.5–110 m diameter). Room fronts sit at 78%, with inward-facing terraces between. Four small conceptual circulation markers sit at 89%. Their curved paths are sculptural placeholders, not resolved lift shafts. The curved form and sightlines are artistic, not construction documentation.

Raw original geometry is unchanged under source/. The source model view preserves the uploaded mesh. Superseded level 101–200 sheets are archived in previous-200-floor-sheets and are excluded from the current drawing set. build.py regenerates the current model data, plans, elevations, section, and floor schedule.
